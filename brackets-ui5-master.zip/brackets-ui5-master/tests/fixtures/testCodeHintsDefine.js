sap.ui.define([
    "test/BaseController",
    "sap/ui/base/EventProvider",
    "sap/ui/base/Object", ""
    "ssrt",
    "sap",
    "sap.u",
    "sap.",
    "sap/",
    "sap/ui"
], function (BaseController, EventProvider, SapObject) {
    "use strict";

    return BaseController.extend("test.App", {

        onInit: function () {
            const tree = new EventProvider();
            const item = new SapObject();
            tree
            tree.
            tree.des
            item.
            item.g
            tree.des(param1)

            this.param = new EventProvider();
            this.param.des
        }
    });
});
