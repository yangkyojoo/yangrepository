# Contributing

- in case of any question the best way to contact me is via email wozjac@zoho.com or LinkedIn (https://www.linkedin.com/in/jacek-wznk)
- if you have found any bug submitting it to the Issues or letting my know will be highly appreciated
- if you want to contribute - feel free to contact, especially if you have some experience with Tern and/or Acorn

Please check the .github folder for issue/pull request templates.