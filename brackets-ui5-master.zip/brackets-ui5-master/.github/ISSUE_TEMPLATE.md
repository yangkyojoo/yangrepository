## Steps to reproduce the issue

1.

## Expected result

## Actual result

## Other details

Extension version:

Brackets version:

Operating system: 

Please open the Brackets console (F12) and paste an error stack trace, if present.